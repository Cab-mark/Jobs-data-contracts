"""
Jobs API module - Pydantic models for Jobs API

Generated from schemas/jobs/openapi.yaml
"""

# Jobs API schema is currently empty, so no models to export
__all__: list[str] = []
